# mtgatracker_backend

## これは何？

MTGATrackerのバックエンド部分を独自に改修したものです。
commentary_backendと組み合わせてMTG Arenaを自動実況するために使用します。
詳細はcommentary_backendのreadmeを参照してください。

## 配布場所

https://github.com/poslogithub/binary-dist

## ライセンス

LICENSEフォルダを参照してください。

このreadmeを書いた人：poslogithub
