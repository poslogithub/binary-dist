# mtgatracker_backend


## これは何？

MTGATrackerのバックエンド部分を独自に改修したものです。
commentary_backendと組み合わせてMTG Arenaを自動実況するために使用します。
詳細はcommentary_backendのreadmeを参照してください。


## 使い方

MTG Arenaを起動してから起動してください。
zipを展開して、mtgatracker_backend.exeを実行すると起動します。
MTG Arenaのインストールパスをレジストリに探しに行ったりするので、セキュリティ警告が表示される場合があります。
コマンドプロンプトが表示されている限り起動しています。
停止する場合はコマンドプロンプトを閉じてください。


## ライセンス

LICENSEフォルダを参照してください。


## 参考URL

* 配布場所：https://github.com/poslogithub/windows-binary-dist
* ソース：https://github.com/poslogithub/mtgatracker
* commentary_backend：https://github.com/poslogithub/windows-binary-dist
* MTGATracker：https://mtgatracker.com/
* MTG Arena：https://mtg-jp.com/mtgarena/
